// State Management
let tasks = JSON.parse(localStorage.getItem('pop_tasks')) || [
  { id: '1', title: 'デザインのレビュー', priority: 'high', tag: '仕事', completed: false },
  { id: '2', title: '牛乳とパンを買う', priority: 'medium', tag: '買い物', completed: true }
];

let currentFilter = 'all';
let currentView = 'kanban';

// DOM Elements
const taskForm = document.getElementById('task-form');
const taskTitle = document.getElementById('task-title');
const taskPriority = document.getElementById('task-priority');
const taskTag = document.getElementById('task-tag');
const progressBarFill = document.getElementById('progress-bar-fill');
const progressText = document.getElementById('progress-text');
const offlineBanner = document.getElementById('offline-banner');

const countTodo = document.getElementById('count-todo');
const countCompleted = document.getElementById('count-completed');

const listTodo = document.getElementById('list-todo');
const listCompleted = document.getElementById('list-completed');
const listFlat = document.getElementById('list-flat');

// Initialization
document.addEventListener('DOMContentLoaded', () => {
  renderTasks();
  setupEventListeners();
  checkOnlineStatus();
});

// Sync online/offline status
function checkOnlineStatus() {
  if (navigator.onLine) {
    offlineBanner.classList.add('hidden');
  } else {
    offlineBanner.classList.remove('hidden');
  }
}

window.addEventListener('online', checkOnlineStatus);
window.addEventListener('offline', checkOnlineStatus);

// Event Listeners
function setupEventListeners() {
  taskForm.addEventListener('submit', (e) => {
    e.preventDefault();
    addTask(taskTitle.value.trim(), taskPriority.value, taskTag.value.trim());
    taskTitle.value = '';
    taskTag.value = '';
  });

  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      e.target.classList.add('active');
      currentFilter = e.target.dataset.filter;
      renderTasks();
    });
  });

  document.getElementById('view-kanban-btn').addEventListener('click', () => setView('kanban'));
  document.getElementById('view-list-btn').addEventListener('click', () => setView('list'));

  // Drag and Drop
  setupDragAndDrop();
}

function setView(view) {
  currentView = view;
  document.getElementById('view-kanban-btn').classList.toggle('active', view === 'kanban');
  document.getElementById('view-list-btn').classList.toggle('active', view === 'list');
  document.getElementById('kanban-view').classList.toggle('active', view === 'kanban');
  document.getElementById('list-view').classList.toggle('active', view === 'list');
}

// Data Operations
function saveTasks() {
  localStorage.setItem('pop_tasks', JSON.stringify(tasks));
  renderTasks();
}

function addTask(title, priority, tag) {
  if (!title) return;
  const newTask = {
    id: Date.now().toString(),
    title,
    priority,
    tag: tag || '一般',
    completed: false
  };
  tasks.push(newTask);
  saveTasks();
}

function toggleTask(id) {
  tasks = tasks.map(t => {
    if (t.id === id) {
      const nextCompleted = !t.completed;
      if (nextCompleted && typeof confetti === 'function') {
        confetti({ particleCount: 70, spread: 60, origin: { y: 0.7 } });
      }
      return { ...t, completed: nextCompleted };
    }
    return t;
  });
  saveTasks();
}

function deleteTask(id) {
  tasks = tasks.filter(t => t.id !== id);
  saveTasks();
}

// Render UI
function renderTasks() {
  listTodo.innerHTML = '';
  listCompleted.innerHTML = '';
  listFlat.innerHTML = '';

  const filteredTasks = tasks.filter(t => {
    if (currentFilter === 'todo') return !t.completed;
    if (currentFilter === 'completed') return t.completed;
    return true;
  });

  filteredTasks.forEach(task => {
    const el = createTaskElement(task);
    if (currentView === 'kanban') {
      if (task.completed) {
        listCompleted.appendChild(el);
      } else {
        listTodo.appendChild(el);
      }
    } else {
      listFlat.appendChild(el);
    }
  });

  // Update Counters & Progress
  const total = tasks.length;
  const completedCount = tasks.filter(t => t.completed).length;
  const todoCount = total - completedCount;

  countTodo.textContent = todoCount;
  countCompleted.textContent = completedCount;

  const percentage = total === 0 ? 0 : Math.round((completedCount / total) * 100);
  progressBarFill.style.width = `${percentage}%`;
  progressText.textContent = `${percentage}% 完了`;
}

function createTaskElement(task) {
  const item = document.createElement('div');
  item.className = `task-item ${task.completed ? 'completed' : ''}`;
  item.draggable = true;
  item.dataset.id = task.id;

  const priorityLabels = { low: '🌱 低', medium: '🔥 中', high: '💥 高' };

  item.innerHTML = `
    <div class="task-header-row">
      <span class="task-title">${escapeHtml(task.title)}</span>
      <span class="priority-tag priority-${task.priority}">${priorityLabels[task.priority]}</span>
    </div>
    <div class="task-footer-row">
      <span class="tag-label">#${escapeHtml(task.tag)}</span>
      <div class="task-actions">
        <button class="action-btn toggle-btn-action" title="状態変更">
          ${task.completed ? '↩️' : '✅'}
        </button>
        <button class="action-btn delete-btn-action" title="削除">🗑️</button>
      </div>
    </div>
  `;

  item.querySelector('.toggle-btn-action').addEventListener('click', () => toggleTask(task.id));
  item.querySelector('.delete-btn-action').addEventListener('click', () => deleteTask(task.id));

  item.addEventListener('dragstart', (e) => {
    e.dataTransfer.setData('text/plain', task.id);
  });

  return item;
}

function setupDragAndDrop() {
  const columns = [listTodo, listCompleted];
  columns.forEach(col => {
    col.addEventListener('dragover', (e) => e.preventDefault());
    col.addEventListener('drop', (e) => {
      e.preventDefault();
      const id = e.dataTransfer.getData('text/plain');
      const targetCompleted = col.id === 'list-completed';
      tasks = tasks.map(t => t.id === id ? { ...t, completed: targetCompleted } : t);
      if (targetCompleted && typeof confetti === 'function') {
        confetti({ particleCount: 70, spread: 60, origin: { y: 0.7 } });
      }
      saveTasks();
    });
  });
}

function escapeHtml(str) {
  return str.replace(/[&<>"']/g, m => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  })[m]);
}
